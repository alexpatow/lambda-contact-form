"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var parseConfig_1 = require("./parseConfig");
describe('parseConfig', function () {
    beforeAll(function () {
        process.env = {};
    });
    it('should successfully parse with valid config', function () {
        var expectation = {
            recaptchaAddr: 'test',
            recaptchaSecret: 'test2',
            sendEmailAddr: 'test@test.com',
        };
        process.env = {
            EMAIL_ADDRESS: 'test@test.com',
            RECAPTCHA_ADDRESS: 'test',
            RECAPTCHA_SECRET: 'test2',
        };
        var response = parseConfig_1.default();
        expect(response).toEqual(expectation);
    });
    it('should throw with invalid config', function () {
        process.env = {
            RECAPTCHA_ADDRESS: 'test',
            RECAPTCHA_SECRET: 'test2',
        };
        expect.assertions(1);
        try {
            parseConfig_1.default();
        }
        catch (err) {
            expect(err).toEqual(new Error('missing required config properties'));
        }
    });
});
//# sourceMappingURL=parseConfig.test.js.map